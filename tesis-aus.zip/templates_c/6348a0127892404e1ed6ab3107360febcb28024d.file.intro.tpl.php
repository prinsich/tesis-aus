<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-17 16:36:23
         compiled from ".\templates\intro.tpl" */ ?>
<?php /*%%SmartyHeaderCode:212656eb0737108c46-22852969%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6348a0127892404e1ed6ab3107360febcb28024d' => 
    array (
      0 => '.\\templates\\intro.tpl',
      1 => 1426263170,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '212656eb0737108c46-22852969',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56eb073710c668_46765613',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56eb073710c668_46765613')) {function content_56eb073710c668_46765613($_smarty_tpl) {?><h1>Acerca del sistema...</h1> 
<h2>Alumnos</h2>
<p>Esta secci&oacute;n permite agregar nuevos alumnos al sistema, modificarlos, eliminarlos, buscarlos y mostrar su informaci&oacute;n.</p>
<h2>Capacitadores</h2>
<p>Esta secci&oacute;n permite agregar nuevos capacitadores al sistema, modificarlos, eliminarlos, buscarlos y mostrar su informaci&oacute;n.</p>
<h2>Talleres</h2>
<p>Esta secci&oacute;n permite agregar nuevos talleres al sistema, modificarlos, eliminarlos, buscarlos y mostrar su informaci&oacute;n.</p>
<p>Al comenzar un nuevo ciclo es recomendable utilizar la opci&oacute;n <b>Resetear Talleres</b> para desvincular los talleres de sus alumnos. <i>(Nota: No se eliminan alumnos ni talleres, s&oacute;lo el v&iacute;nculo entre ellos)</i>.</p>
<h2>Certificados</h2>
<p>Esta secci&oacute;n permite crear los certificados de capacitaci&oacute;n para cada alumno de los talleres.</p>

<?php }} ?>
