<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-12 22:23:28
         compiled from ".\templates\404_not_found.html" */ ?>
<?php /*%%SmartyHeaderCode:3085056e4c006850550-75518069%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '66f40defa5fc5d2750f6122678c5c1e17264b38f' => 
    array (
      0 => '.\\templates\\404_not_found.html',
      1 => 1457832207,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3085056e4c006850550-75518069',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e4c006853a77_54985562',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e4c006853a77_54985562')) {function content_56e4c006853a77_54985562($_smarty_tpl) {?><h1>Oops!</h1>
<h2>404 No Encontrado</h2>
<div class="error-details">
    <p>Lo sentimos, ha ocurrido un error, pidi&oacute; a p&aacute;gina no encontrada<p>
</div>
<?php }} ?>
