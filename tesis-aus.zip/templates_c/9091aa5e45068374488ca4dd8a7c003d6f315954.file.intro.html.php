<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-12 22:25:05
         compiled from ".\templates\intro.html" */ ?>
<?php /*%%SmartyHeaderCode:1374256e4c171d8d468-61518265%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9091aa5e45068374488ca4dd8a7c003d6f315954' => 
    array (
      0 => '.\\templates\\intro.html',
      1 => 1426263170,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1374256e4c171d8d468-61518265',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e4c171d91106_83265073',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e4c171d91106_83265073')) {function content_56e4c171d91106_83265073($_smarty_tpl) {?><h1>Acerca del sistema...</h1> 
<h2>Alumnos</h2>
<p>Esta secci&oacute;n permite agregar nuevos alumnos al sistema, modificarlos, eliminarlos, buscarlos y mostrar su informaci&oacute;n.</p>
<h2>Capacitadores</h2>
<p>Esta secci&oacute;n permite agregar nuevos capacitadores al sistema, modificarlos, eliminarlos, buscarlos y mostrar su informaci&oacute;n.</p>
<h2>Talleres</h2>
<p>Esta secci&oacute;n permite agregar nuevos talleres al sistema, modificarlos, eliminarlos, buscarlos y mostrar su informaci&oacute;n.</p>
<p>Al comenzar un nuevo ciclo es recomendable utilizar la opci&oacute;n <b>Resetear Talleres</b> para desvincular los talleres de sus alumnos. <i>(Nota: No se eliminan alumnos ni talleres, s&oacute;lo el v&iacute;nculo entre ellos)</i>.</p>
<h2>Certificados</h2>
<p>Esta secci&oacute;n permite crear los certificados de capacitaci&oacute;n para cada alumno de los talleres.</p>

<?php }} ?>
