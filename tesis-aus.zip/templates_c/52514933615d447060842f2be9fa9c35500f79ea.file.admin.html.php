<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-23 09:10:42
         compiled from ".\templates\admin\admin.html" */ ?>
<?php /*%%SmartyHeaderCode:763056e2fe3dc4cd61-54649870%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52514933615d447060842f2be9fa9c35500f79ea' => 
    array (
      0 => '.\\templates\\admin\\admin.html',
      1 => 1466683829,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '763056e2fe3dc4cd61-54649870',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e2fe3dc50014_88618647',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e2fe3dc50014_88618647')) {function content_56e2fe3dc50014_88618647($_smarty_tpl) {?><h1>Area de Administraci&oacute;n</h1>
<p>Bienvenido al &aacute;rea de Administraci&oacute;n de Usuarios y Registros del Sistema. En esta secci&oacute;n usted podr&aacute; crear, modificar, buscar y eliminar a los usuarios que acceden al sistema adem&aacute;s de visualizar todos los movimientos generados en el mismo.</p>
<?php }} ?>
