<?php
$archivo = $sub.".php";
if (file_exists("includes/capacitadores/".$archivo)) {
    include ("includes/capacitadores/".$archivo );
}
