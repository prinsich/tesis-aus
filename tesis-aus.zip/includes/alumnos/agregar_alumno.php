<?php
$smarty->assign("usrlogin", $usrlogin);
$smarty->assign("fecha_hoy", date("Y-m-d")."T23:59:59");

