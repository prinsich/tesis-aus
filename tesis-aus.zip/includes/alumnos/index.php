<?php
$archivo = $sub.".php";
if (file_exists("includes/alumnos/".$archivo)) {
    include ("includes/alumnos/".$archivo );
}
