<?php
$archivo = $sub.".php";
if (file_exists("includes/login/".$archivo)) {
    include ("includes/login/".$archivo );
}
